
public class Maruti extends Car{
	
	Maruti(int id,String model,int price)
	{
		this.id=id;
		this.model=model;
		this.price=price;
		resaleValues= 0.6*price;
		carName="Maruti";
	}
}
