
public abstract class Car{
	 int id;
	 String model;
	 int price;
	 double resaleValues;
	 String carName;
}